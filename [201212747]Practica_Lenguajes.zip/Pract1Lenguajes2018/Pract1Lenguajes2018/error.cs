﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract1Lenguajes2018
{
    class error
    {
        public string lexema;
        public string tipo;

        public error(string lexema, string tipo)
        {
            this.lexema = lexema;
            this.tipo = tipo; 
        }

        public string Lexema
        {
            get { return lexema;}
            set { lexema = value; }
        }

        public string Tipo
        {
            get { return tipo;}
            set { tipo = value; }

        }
    }
}
